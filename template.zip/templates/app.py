from flask import Flask, render_template, request, redirect, url_for, session
app = Flask(__name__)
app.secret_key = "your_secret_key"  # Replace with a strong secret key

users = {}

class User:
    def __init__(self, username, family_income, expenses):
        self.username = username
        self.family_income = family_income
        self.expenses = expenses

    def calculate_savings(self):
        return self.family_income - self.expenses

class FinancialAdvisor:
    def __init__(self):
        pass

    def suggest_investment(self, savings):
        if savings > 2000:
            return "You have a good amount of savings. Consider investing in diversified stocks or real estate."
        elif 1000 <= savings <= 2000:
            return "You have moderate savings. Consider a balanced portfolio of bonds and mutual funds."
        else:
            return "Your savings are low. Focus on building an emergency fund first."

advisor = FinancialAdvisor()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        family_income = float(request.form['family_income'])
        expenses = float(request.form['expenses'])
        if username in users:
            return "Username already exists. Please choose a different username."
        users[username] = User(username, family_income, expenses)
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        if username in users:
            session['username'] = username
            return redirect(url_for('dashboard'))
        return "Username not found. Please register first."
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        username = session['username']
        user = users[username]
        savings = user.calculate_savings()
        investment_advice = advisor.suggest_investment(savings)
        return render_template('dashboard.html', username=username, family_income=user.family_income, 
                               expenses=user.expenses, savings=savings, investment_advice=investment_advice)
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
